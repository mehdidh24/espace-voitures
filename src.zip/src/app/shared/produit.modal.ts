export class Produit {
id: string='';
name: string='';
description: string='';

price: number=0;
currency: string=''; 
stock: number=0;
category: string='';
images: string[]=[];
}